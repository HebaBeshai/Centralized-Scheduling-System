import pymysql


class Database:
    def __init__(self):
        host = 'localhost'
        user = 'class'
        password = 'software331'
        db = 'xylem'

        self.con = pymysql.connect(host=host, user=user, password=password, db=db, cursorclass=pymysql.cursors.
                                   DictCursor)
        self.cur = self.con.cursor()

    def list_departments(self, value=''):
        if len(value) > 0:
            if len(value) == 3:
                self.cur.execute("SELECT ID, Name FROM departments WHERE ID = '%s'" % value)
            else:
                self.cur.execute("SELECT ID, Name FROM departments WHERE Name = '%s'" % value)
        else:
            self.cur.execute("SELECT * FROM departments")

        return self.cur.fetchall()

    def list_courses(self, value=''):
        if len(value) > 0:
            if len(value) == 3 and value[0].isalpha():
                self.cur.execute("SELECT * FROM courses WHERE Department = '%s'" % value)
            else:
                self.cur.execute("SELECT * FROM courses WHERE Number = '%s'" % value)
        else:
            self.cur.execute("SELECT * FROM courses")

        return self.cur.fetchall()

    def get_course_name(self, department, number):
        self.cur.execute("SELECT DISTINCT(Name) FROM sections WHERE (Department = '%s' AND Number = '%s')" % (department, number))

        return self.cur.fetchall()

    def list_sections(self, department, number):
        self.cur.execute("SELECT * FROM sections WHERE (Department = '%s' AND Number = '%s')" % (department, number))

        return self.cur.fetchall()

    def get_section(self, CRN):
        self.cur.execute("SELECT * FROM sections WHERE CRN = %d" % CRN)

        return self.cur.fetchone()