from flask import Flask, render_template, session, request, url_for, redirect
from flask.json import jsonify
import pymysql
from flask_bootstrap import Bootstrap
from flask_wtf.csrf import CSRFProtect
from flask_nav.elements import Navbar, View
from itertools import product
from forms import CourseForm
from database import Database

app = Flask(__name__)
app.config["SECRET_KEY"] = 'key'
Bootstrap(app)        
db = Database()
day_codes = 'MTWRF'

@app.route('/')
def index():
  return render_template('home.html')

@app.route('/courses', methods=['GET', 'POST'])
def course():
  form = CourseForm()
  departments = db.list_departments()
  form.department.choices = [(department['ID'], department['Name']) for department in departments]
  form.course.choices = [(course['Number'], course['Number']) for course in db.list_courses(departments[0]['ID'])]
  
  if request.method == 'POST':
    if request.form['submit'] == 'Submit Course':
      department = form.department.data
      course = form.course.data
      if 'courses' in session:
        courses = session['courses']
        if [department, course] not in courses:
          courses.append([department, course])
        session['courses'] = courses
      else:
        session['courses'] = [[department, course]]
      
      form.course.choices = [(course['Number'], course['Number']) for course in db.list_courses(department)]
      return render_template('course.html', form=form, courses=session['courses'])
    elif request.form['submit'] == 'Generate Schedules':
      return redirect(url_for('schedule'))

  session['courses'] = []
  
  return render_template('course.html', form=form, courses=[])
  

@app.route('/schedule')
def schedule():
  sections = []
  session['schedules'] = []
  for course in session['courses']:
    sections.append([])
    for section in db.list_sections(course[0], course[1]):
      sections[len(sections)-1].append([section['CRN'], section['Department'], section['Number'], section['Start Time'], section['End Time'], section['Days'] ])
  
  if len(sections) > 0:
    schedules = product(*sections)
    valid_schedules = []
  
    for schedule in schedules:
      days = [[] for _ in range(5)]
      for section in schedule:
        for code, day in enumerate(days):
          if day_codes[code] in section[5]:
            day.append((section[3], 's'))
            day.append((section[4], 'e'))
      
      valid_schedules.append([[str(item) for item in course] for course in schedule])
      for day in days:
        day.sort(key=lambda tup: tup[0])
        events = ''.join(event[1] for event in day)
        
        if 'ss' in events:
          valid_schedules.pop()
          break
      
      session['schedules'] = valid_schedules
    
  return render_template('schedule.html', courses=session['courses'], schedules=session['schedules'])
  
@app.route('/courses/<department>')
def courses(department):
  courses = db.list_courses(department)
  
  return jsonify({'courses' : courses})

    
  
    