let department_selection = document.getElementById('department');
let course_selection = document.getElementById('course');

department_selection.onchange = function() {
  department = department_selection.value;
  
  fetch('/courses/' + department).then(function(response) {
    response.json().then(function(data) {
      let optionHTML = '';
      for (let course of data.courses) {
        optionHTML += '<option value"' + course.Number + '">' + course.Number + '</option>';
      }
      
      course_selection.innerHTML = optionHTML;
    });
  });
};

  